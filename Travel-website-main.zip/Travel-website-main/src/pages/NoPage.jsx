import React from "react";

const NoPage = () => {
  return <div>NoPage</div>;
  // https://medium.com/frontendweb/how-to-pass-state-or-data-in-react-router-v6-c366db9ee2f4
  // https://royeraadames.medium.com/open-react-router-link-at-top-of-page-c8e48a72da99
};

export default NoPage;
